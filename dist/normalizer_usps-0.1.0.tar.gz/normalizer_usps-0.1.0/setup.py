from setuptools import setup, find_packages

setup(
    name='normalizer_usps',
    version='0.1.0',
    description='A library for normalizing addresses.',
    author='Larissa Lima',
    author_email='larissabeatrizlima@outlook.com',
    packages=find_packages(),
    include_package_data=True,
    package_data={'normalizer_usps': ['data/*.json']},
    install_requires=[
        'pandas',
        'importlib_resources; python_version < "3.9"',
    ],
)